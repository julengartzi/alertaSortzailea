package alertaSortzailea;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

/**
 * Alerten erregistroa kudeatzeko klasea.
 */
public class erregistroaGestionatu extends JFrame {
    private DefaultTableModel tableModel;
    private JTable table;

    /**
     * Klase eraikitzailea.
     */
    public erregistroaGestionatu() {
        setTitle("Alertak gestionatu");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 400);

        tableModel = new DefaultTableModel();
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        gaituTablaEditatzea();

        JButton aldaketakGordeBotoia = new JButton("Aldaketak Gorde");
        aldaketakGordeBotoia.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	datuBaseanDatuakGorde();
            }
        });

        JButton ezabatuBotoia = new JButton("Ezabatu");
        ezabatuBotoia.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                erregistroaEzabatu();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(aldaketakGordeBotoia);
        buttonPanel.add(ezabatuBotoia);

        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

	/**
	 * Taularen eguneratu ResultSet-eko datuekin.
	 * 
	 * @param resultSet SQL kontsultaren emaitza-multzoa.
	 * @throws SQLException ResultSet erabiltzean akatsen bat gertatzen bada.
	 */
	public void updateTableModel(ResultSet resultSet) throws SQLException {
		tableModel.setRowCount(0);

		int columnCount = resultSet.getMetaData().getColumnCount();

		for (int i = 1; i <= columnCount; i++) {
			tableModel.addColumn(resultSet.getMetaData().getColumnName(i));
		}
		while (resultSet.next()) {
			Object[] row = new Object[columnCount];
			for (int i = 1; i <= columnCount; i++) {
				row[i - 1] = resultSet.getObject(i);
			}
			tableModel.addRow(row);
		}
	}

    /**
     * Taula editatzeko aukera ematen du.
     */
    private void gaituTablaEditatzea() {
        for (int i = 0; i < table.getColumnCount(); i++) {
            if (i != 0) { // Saihestu lehen eremua (ID) editagarria izatea
                table.getColumnModel().getColumn(i).setCellEditor(new DefaultCellEditor(new JTextField()));
            } else {
                table.getColumnModel().getColumn(i).setCellEditor(null);
            }
        }
    }

    /**
     * Datu-basean egindako aldaketak gordetzen ditu.
     */
    private void datuBaseanDatuakGorde() {
        Connection conn = null;
        try {
            conn = Konexioa.getConnection(); 
            conn.setAutoCommit(false); // Transakziorako baieztapen automatikoa desgaitzen du

            Statement stmt = conn.createStatement();
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                String gaia = tableModel.getValueAt(i, 1).toString();
                String deskribapena = tableModel.getValueAt(i, 2).toString();
                String jasotzailea = tableModel.getValueAt(i, 3).toString();
                String data = tableModel.getValueAt(i, 4).toString();
                String ordua = tableModel.getValueAt(i, 5).toString();

                // ID-a ez da eguneratzen
                String id = tableModel.getValueAt(i, 0).toString();

                String query = "UPDATE mezua SET gaia = '" + gaia + "', deskribapena = '" + deskribapena +
                               "', jasotzailea = '" + jasotzailea + "', data = '" + data +
                               "', ordua = '" + ordua +  "' WHERE id = '" + id + "'";
                stmt.executeUpdate(query);
            }

            conn.commit(); // Berretsi transakzioa
            JOptionPane.showMessageDialog(null, "Aldaketak ondo gorde dira.");
        } catch (SQLException ex) {
            ex.printStackTrace();
            try {
                if (conn != null) {
                    conn.rollback(); // Akatsen bat badago, transakzioa desegiten du
                }
            } catch (SQLException exRollback) {
                exRollback.printStackTrace();
            }
        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true); // Gaitu berriro berrespen automatikoa
                    conn.close();
                }
            } catch (SQLException exClose) {
                exClose.printStackTrace();
            }
        }
    }

    /**
     * Datu-baseko erregistro bat ezabatzen du.
     */
    private void erregistroaEzabatu() {
        int filaSeleccionada = table.getSelectedRow();
        if (filaSeleccionada != -1) {
            String id = tableModel.getValueAt(filaSeleccionada, 0).toString();
            int confirmacion = JOptionPane.showConfirmDialog(this, "¿Seguru zaude erregistroa ezabatu nahi duzula?", "Konfirmatu", JOptionPane.YES_NO_OPTION);
            if (confirmacion == JOptionPane.YES_OPTION) {
                try {
                    Connection conn = Konexioa.getConnection();
                    String query = "DELETE FROM mezua WHERE id = ?";
                    PreparedStatement statement = conn.prepareStatement(query);
                    statement.setString(1, id);
                    statement.executeUpdate();
                    conn.close();
                    JOptionPane.showMessageDialog(this, "Erregistroa ondo ezabatu da.");
                    
                    // Ezabatutako erregistroa tablatik kendu.
                    tableModel.removeRow(filaSeleccionada);

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Errorea erregistroa ezabatzeko garaian: " + ex.getMessage(), "Errorea", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Aukeratu erregistro bat ezabatzeko.", "Errorea", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Taula datu-baseko datuekin eguneratzen du.
     */
    private void updateTableModelFromDatabase() {
        try {
            Connection conn = Konexioa.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet resultSet = stmt.executeQuery("SELECT * FROM mezua");
            updateTableModel(resultSet);
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Errorea taula aktualizatzeko garaian: " + ex.getMessage(), "Errorea", JOptionPane.ERROR_MESSAGE);
        }
    }
}