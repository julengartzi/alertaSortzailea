package alertaSortzailea;

import javax.swing.JOptionPane;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

/**
 * Mezu elektronikoak bidaltzeko klasea.
 */
public class emailbidaltzailea {

    /**
     * Mezu elektroniko bat bidaltzeko metodoa.
     * 
     * @param gaia          Mezuaren gaia.
     * @param deskribapena  Mezuaren gorputza.
     * @param jasotzailea   Mezuaren jasotzailea.
     */
    public static void bidali(String gaia, String deskribapena, String jasotzailea) {
        // Bidaltzailearen datuak
        String remitente = "ZURE EMAILA";
        String password = "GOOGLEKO PASAHITZ BEREZIA-IRAKURRI TEXTUA";

        // Propietateak konfiguratu
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        // Posta-saioa lortu
        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(remitente, password);
                    }
                });

        try {
            // Mezu-objektu bat sortzea
            Message message = new MimeMessage(session);
            // Establecer el remitente
            message.setFrom(new InternetAddress(remitente));
            // Bidaltzailea ezarri
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(jasotzailea));
            // Gaia ezarri
            message.setSubject(gaia);
            // Mezuaren gorputza ezarri
            message.setText(deskribapena);

            // Mezua bidali
            Transport.send(message);

            // Bistaratu elkarrizketa-koadroa, mezu elektronikoa behar bezala bidali dela adieraziz
            JOptionPane.showMessageDialog(null, "Emaila ondo bidali da.", "Email Bidaltzea", JOptionPane.INFORMATION_MESSAGE);

        } catch (MessagingException e) {
            // Mezua bidaltzean errore bat gertatzen bada, salbuespen bat egin
            throw new RuntimeException(e);
        }
    }
}

