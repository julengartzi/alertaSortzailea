package alertaSortzailea;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Klase hau datu basearekin konexioa ezartzeko erabiltzen da.
 */
public class Konexioa {
    
    static final String DB_URL = "jdbc:mysql://localhost:3306/alertasortzailea";
    static final String USER = "root";
    static final String PASS = "";
    
    /**
     * Datu basearekin konexioa egiteko ahalbidetzen du.
     * 
     * @return Konexio objektua.
     * @throws SQLException Konexioak egitean sortu daitezkeen SQL akatsak.
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, USER, PASS);
    }

}

