package alertaSortzailea;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Datu-basearekiko konexioa eta eragiketak maneiatzen dituen klasea.
 */
public class DatuBasea {

    /**
     * Datu-basean datuak txertatzeko metodoa.
     * 
     * @param gaia          mezuaren gaia.
     * @param deskribapena  Mezuaren deskripzioa.
     * @param jasotzailea   Mezuaren jasotzailea.
     * @param data          Mezuaren data.
     * @param ordua         Mezuaren ordua.
     */
    public static void datuakSartu(String gaia, String deskribapena, String jasotzailea, Date data, Date ordua) {
        try {
        	// Datu-baserako konexioa lortzen dugu
            Connection connection = Konexioa.getConnection();
            Statement stmt = connection.createStatement();

         // Datak formateatuko ditugu, datu-basean eskatutako formatura egokitzeko
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            SimpleDateFormat horaFormat = new SimpleDateFormat("HH:mm");
            String dataStr = dateFormat.format(data);
            String orduaStr = horaFormat.format(ordua);

            // Datuak sartzeko SQL sententzia eraikitzen dugu.
            String sql_insert = "INSERT INTO mezua(gaia, deskribapena, jasotzailea, data, ordua) "
                    + "VALUES('" + gaia + "', '" + deskribapena + "', '" + jasotzailea + "', '" + dataStr + "', '"
                    + orduaStr + "')";

            // Sententzia exekutatzen dugu.
            stmt.executeUpdate(sql_insert);
            System.out.println("Datuak sartu dira DBan");

            // Statement eta konexioa ixten dugu.
            stmt.close();
            connection.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * SQL kontsulta bat exekutatzeko eta ResultSet itzultzeko metodoa.
     * 
     * @param exekutatu beharreko SQL kontsulta.
     * @return Kontsultaren emaitza multzoa.
     * @throws SQLException Si ocurre un error durante la ejecución de la consulta.
     */
    public static ResultSet executeQuery(String query) throws SQLException {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try {
            // Datu-baserako konexioa lortzen dugu
            connection = Konexioa.getConnection();
            statement = connection.createStatement();
            // SQL kontsulta exekutatu eta ResultSet  gordeko dugu
            resultSet = statement.executeQuery(query);
        } finally {
        }
        // Kontsultaren emaitzak dituen ResultSet mezua itzuliko dugu
        return resultSet;
    }

}


